package com.jarvix.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Always-on listener. Say "Hey Jarvix" (or "জার্ভিক্স"), then your instruction. */
class ListenService : Service(), TextToSpeech.OnInitListener {

    companion object { @Volatile var running = false }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var commands: Commands
    private var ttsReady = false
    private var speaking = false
    private var activeUntil = 0L          // conversation session: no wake word needed until this time
    private val SESSION_MS = 40_000L
    private val langs = listOf("bn-BD", "en-US")
    private var langIdx = 0
    private val restart = Runnable { startListening() }

    private val wakeWords = listOf(
        "jarvix", "jarvis", "jarvics", "jarvik", "javis",
        "জার্ভিক্স", "জারভিক্স", "জার্ভিস", "জারভিস", "যারভিস", "জার্বিস", "জার্ভিক্ষ", "জার্ভিছ", "জারভিছ"
    )
    private val fillers = setOf("hey", "hi", "ok", "okay", "হে", "ওহে", "হ্যালো", "এই")
    private val endWords = listOf("stop listening", "goodbye", "bye bye", "that's all", "thats all",
        "ধন্যবাদ", "থামো", "বিদায়", "থাক", "শোনা বন্ধ")

    override fun onCreate() {
        super.onCreate()
        commands = Commands(this)
        tts = TextToSpeech(this, this)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { extendSession(); speaking = false; startListening() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { speaking = false; startListening() } }
        })
    }

    override fun onInit(code: Int) { ttsReady = code == TextToSpeech.SUCCESS }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            running = false
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        running = true
        startListening()
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvix", "Jarvix", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, ListenService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "jarvix")
            .setContentTitle("Jarvix is listening")
            .setContentText("Say \"Hey Jarvix\" / বলুন \"হে জার্ভিক্স\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stop).build())
            .build()
    }

    private fun schedule(delayMs: Long) {
        main.removeCallbacks(restart); main.postDelayed(restart, delayMs)
    }

    private fun startListening() {
        if (!running || speaking) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            running = false; stopSelf(); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { schedule(5000); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val list = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                    handleHeard(list)
                }
                override fun onError(e: Int) {
                    langIdx = (langIdx + 1) % langs.size
                    schedule(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 500)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, langs[langIdx])
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        recognizer?.startListening(i)
    }

    private fun extendSession() {
        val n = System.currentTimeMillis()
        if (activeUntil > n) activeUntil = n + SESSION_MS
    }

    private fun stripWake(low: String): String {
        var t = low
        wakeWords.forEach { t = t.replace(it, " ") }
        return t.split(" ").filter { it.isNotBlank() && it !in fillers }.joinToString(" ").trim()
    }

    private fun handleHeard(options: List<String>) {
        if (options.isEmpty()) { schedule(300); return }
        val now = System.currentTimeMillis()

        // Active conversation: every sentence is a command until you say goodbye or go quiet.
        if (now < activeUntil) {
            val heard = options.first()
            val low = heard.lowercase()
            if (endWords.any { low.contains(it) }) {
                activeUntil = 0L
                speak(if (heard.any { it in '\u0980'..'\u09FF' }) "ঠিক আছে। ডাকলেই আসব।" else "Okay. Say Hey Jarvis when you need me.")
                return
            }
            val cleaned = stripWake(low)
            activeUntil = now + SESSION_MS
            if (cleaned.isNotBlank()) run(cleaned) else schedule(200)
            return
        }

        // Waiting for the wake word
        for (text in options) {
            val low = text.lowercase()
            if (wakeWords.none { low.contains(it) }) continue
            val rest = stripWake(low)
            activeUntil = now + SESSION_MS
            if (rest.isBlank()) speak(if (text.any { it in '\u0980'..'\u09FF' }) "জি, বলুন।" else "Yes, I'm listening.")
            else run(rest)
            return
        }
        schedule(200) // nothing for us, keep listening
    }

    private fun run(text: String) {
        commands.handle(text) { reply -> speak(reply) }
    }

    private fun speak(text: String) {
        speaking = true
        main.removeCallbacks(restart)
        recognizer?.destroy(); recognizer = null
        if (!ttsReady) { speaking = false; schedule(300); return }
        val bn = text.any { it in '\u0980'..'\u09FF' }
        val r = tts.setLanguage(if (bn) Locale("bn", "BD") else Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvix")
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(restart)
        recognizer?.destroy(); tts.shutdown()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
