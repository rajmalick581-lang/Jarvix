package com.jarvix.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var commands: Commands
    private var recognizer: SpeechRecognizer? = null
    private var bangla = true
    private var ttsReady = false

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var mic: Button
    private lateinit var lang: Button
    private lateinit var always: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        commands = Commands(this)
        tts = TextToSpeech(this, this)
        buildUi()
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onResume() { super.onResume(); refreshAlways() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A1220"))
            setPadding(40, 80, 40, 40)
        }
        val title = TextView(this).apply { text = "Jarvix"; textSize = 28f; setTextColor(Color.parseColor("#8ED3F0")) }
        lang = Button(this).apply { text = "বাংলা"; setOnClickListener { toggleLang() } }
        always = Button(this).apply { setOnClickListener { toggleAlways() } }
        status = TextView(this).apply {
            text = "ট্যাপ করে কথা বলুন"; textSize = 16f; setTextColor(Color.parseColor("#8DA2B8")); setPadding(0, 24, 0, 24)
        }
        log = TextView(this).apply { textSize = 17f; setTextColor(Color.parseColor("#E6EEF7")); setLineSpacing(6f, 1f) }
        scroll = ScrollView(this).apply { addView(log) }
        mic = Button(this).apply { text = "🎤"; textSize = 32f; setOnClickListener { listen() } }
        root.addView(title); root.addView(lang); root.addView(always); root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mic, LinearLayout.LayoutParams(-1, 220).apply { gravity = Gravity.CENTER })
        setContentView(root)
    }

    private fun refreshAlways() {
        always.text = if (ListenService.running) "🟢 সবসময় শুনছি / Always listening: ON (tap to stop)"
                      else "⚪ \"হে জার্ভিক্স\" চালু করুন / Turn on \"Hey Jarvix\""
    }

    private fun toggleAlways() {
        if (ListenService.running) {
            startService(Intent(this, ListenService::class.java).setAction("STOP"))
            always.postDelayed({ refreshAlways() }, 400); return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = "Allow the microphone, then tap again / মাইকের অনুমতি দিন"
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (!Settings.canDrawOverlays(this)) {
            status.text = "Turn on \"Display over other apps\" for Jarvix, come back, tap again. / \"অন্য অ্যাপের উপরে দেখান\" চালু করুন"
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startForegroundService(Intent(this, ListenService::class.java))
        status.text = "বলুন: হে জার্ভিস / Say: Hey Jarvis"
        always.postDelayed({ refreshAlways() }, 400)
    }

    private fun toggleLang() {
        bangla = !bangla
        lang.text = if (bangla) "বাংলা" else "English"
        status.text = if (bangla) "ট্যাপ করে কথা বলুন" else "Tap to talk"
        applyTtsLocale()
    }

    override fun onInit(code: Int) { ttsReady = code == TextToSpeech.SUCCESS; applyTtsLocale() }

    private fun applyTtsLocale() {
        if (!ttsReady) return
        val r = tts.setLanguage(if (bangla) Locale("bn", "BD") else Locale.US)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US)
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status.text = if (bangla) "মাইকের অনুমতি দিন" else "Allow the microphone"
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (ListenService.running) { status.text = "Always-listening is on. Just say Hey Jarvix."; return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Speech recognition not available"; return }
        tts.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = if (bangla) "শুনছি…" else "Listening…" }
                override fun onResults(r: Bundle?) {
                    val text = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    runCommand(text)
                }
                override fun onError(e: Int) { status.text = if (bangla) "শুনতে পাইনি, আবার ট্যাপ করুন" else "Did not catch that, tap again" }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bangla) "bn-BD" else "en-US")
        recognizer?.startListening(i)
    }

    private fun runCommand(text: String) {
        append("আপনি / You: $text")
        status.text = if (bangla) "ভাবছি…" else "Thinking…"
        commands.handle(text) { reply ->
            append("Jarvix: $reply")
            status.text = if (bangla) "ট্যাপ করে কথা বলুন" else "Tap to talk"
            if (ttsReady) tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "jarvix")
        }
    }

    private fun append(line: String) {
        log.append(line + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onDestroy() { recognizer?.destroy(); tts.shutdown(); super.onDestroy() }
}
