package com.jarvix.app

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class Commands(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Pair<String, String>>()

    /** Runs a spoken or typed instruction. [reply] is always called on the main thread. */
    fun handle(raw: String, reply: (String) -> Unit) {
        val bn = raw.any { it in '\u0980'..'\u09FF' }
        val t = normalize(raw)
        fun say(en: String, bnText: String) = reply(if (bn) bnText else en)

        // Install app: opens its Play Store page (Android requires you to tap Install yourself)
        if (has(t, "install", "download", "ইনস্টল", "ইন্সটল", "ডাউনলোড")) {
            val name = strip(t, "install", "download", "the", "app", "please", "ইনস্টল", "ইন্সটল", "ডাউনলোড", "করো", "কর", "দাও", "দিন", "অ্যাপ", "অ্যাপটা")
            if (name.isBlank()) return say("Which app should I install?", "কোন অ্যাপ ইনস্টল করব?")
            val key = aliases[name] ?: name
            val pkg = knownPackages[key]
            if (pkg != null && openApp(key)) return say("It is already installed. Opening it.", "অ্যাপটা আগেই ইনস্টল করা আছে। খুলছি।")
            openStore(pkg, key)
            return say("Opening the Play Store. Tap Install.", "প্লে স্টোর খুললাম। ইনস্টল চাপুন।")
        }

        // Flashlight
        if (has(t, "torch", "flashlight", "flash light", "টর্চ", "ফ্ল্যাশ", "ফ্লাশ")) {
            val off = has(t, "off", "নিভ", "বন্ধ", "অফ")
            return if (setTorch(!off)) {
                if (off) say("Flashlight off.", "টর্চ বন্ধ করলাম।") else say("Flashlight on.", "টর্চ জ্বালালাম।")
            } else say("No flashlight found.", "ফ্ল্যাশলাইট পাওয়া যায়নি।")
        }

        // Volume
        if (has(t, "volume", "ভলিউম", "আওয়াজ", "শব্দ")) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = has(t, "up", "increase", "louder", "raise", "বাড়া", "বেশি")
            val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
            repeat(2) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) }
            return if (up) say("Volume up.", "ভলিউম বাড়ালাম।") else say("Volume down.", "ভলিউম কমালাম।")
        }

        // Alarm
        if (has(t, "alarm", "অ্যালার্ম", "এলার্ম", "জাগিয়ে")) {
            val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(t)
                ?: return say("What time should I set it for?", "কটার জন্য অ্যালার্ম দেব?")
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].ifEmpty { "0" }.toInt()
            val pm = has(t, "pm", "p.m", "evening", "night", "afternoon", "বিকেল", "সন্ধ্যা", "রাত", "দুপুর")
            if (pm && h < 12) h += 12
            if (h > 23 || min > 59) return say("That time looks wrong.", "সময়টা ঠিক মনে হচ্ছে না।")
            start(Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvix").putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return say("Alarm set for %02d:%02d.".format(h, min), "%02d:%02d এর জন্য অ্যালার্ম দিলাম।".format(h, min))
        }

        // Timer
        if (has(t, "timer", "টাইমার")) {
            val m = Regex("(\\d+)").find(t) ?: return say("For how long?", "কতক্ষণের টাইমার?")
            val n = m.groupValues[1].toInt()
            val secs = when {
                has(t, "hour", "ঘণ্টা", "ঘন্টা") -> n * 3600
                has(t, "second", "সেকেন্ড") -> n
                else -> n * 60
            }
            start(Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return say("Timer started.", "টাইমার চালু করলাম।")
        }

        // Call
        if (has(t, "call", "ring ", "phone", "ফোন", "কল")) {
            val num = Regex("\\+?\\d{6,}").find(t.replace(" ", ""))?.value
                ?: lookupContact(strip(t, "call", "ring", "phone", "please", "to", "ফোন", "কল", "করো", "কর", "দাও", "দিন", "কে"))
                ?: return say("I could not find that contact.", "এই নামে কাউকে পেলাম না।")
            val granted = ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            start(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            return say("Calling.", "ফোন করছি।")
        }

        // Navigation
        if (has(t, "navigate", "directions", "take me to", "নেভিগেট", "রাস্তা", "ম্যাপ")) {
            val place = strip(t, "navigate", "directions", "take", "me", "to", "ম্যাপে", "ম্যাপ", "নেভিগেট", "রাস্তা", "দেখাও", "যাও", "যেতে", "চাই")
            start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
            return say("Opening maps.", "ম্যাপ খুলছি।")
        }

        // Search
        if (has(t, "search", "google", "look up", "খোঁজ", "খুঁজ", "সার্চ")) {
            val q = strip(t, "search", "google", "look", "up", "for", "খোঁজো", "খুঁজো", "খোঁজ", "খুঁজ", "সার্চ", "করো", "কর")
            start(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            return say("Searching.", "খুঁজছি।")
        }

        // Wi-Fi / Bluetooth (Android no longer lets apps toggle these directly)
        if (has(t, "wifi", "wi-fi", "ওয়াইফাই", "ওয়াই-ফাই", "ইন্টারনেট")) {
            start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
            return say("Here are the Wi-Fi controls.", "ওয়াইফাই সেটিংস খুললাম।")
        }
        if (has(t, "bluetooth", "ব্লুটুথ")) {
            start(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            return say("Here are the Bluetooth settings.", "ব্লুটুথ সেটিংস খুললাম।")
        }

        // Battery
        if (has(t, "battery", "ব্যাটারি")) {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val p = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            return say("Battery is at $p percent.", "ব্যাটারি $p শতাংশ আছে।")
        }

        // Open app
        if (has(t, "open", "launch", "start", "খোল", "খুল", "ওপেন", "চালু")) {
            val name = strip(t, "open", "launch", "start", "the", "app", "please", "খোলো", "খুলো", "খোল", "ওপেন", "চালু", "করো", "কর", "দাও")
            if (openApp(name)) return say("Opening.", "খুলছি।")
            val pkg = knownPackages[aliases[name] ?: name]
            if (pkg != null) {
                openStore(pkg, name)
                return say("It is not installed. Opening the Play Store.", "অ্যাপটা ইনস্টল নেই। প্লে স্টোর খুলছি।")
            }
            return say("I could not find that app.", "অ্যাপটা খুঁজে পেলাম না।")
        }

        // Time and date
        if (has(t, "time", "সময়", "কটা", "কয়টা", "বাজে")) {
            val f = SimpleDateFormat("h:mm a", if (bn) Locale("bn", "BD") else Locale.US)
            val s = f.format(Date())
            return say("It is $s.", "এখন $s।")
        }
        if (has(t, "date", "today", "তারিখ", "আজ")) {
            val s = SimpleDateFormat("EEEE, d MMMM yyyy", if (bn) Locale("bn", "BD") else Locale.US).format(Date())
            return say("Today is $s.", "আজ $s।")
        }

        // Anything else goes to Claude (optional)
        if (Config.API_KEY.isBlank()) {
            return say("I did not understand. Try: open YouTube, call Rahim, set alarm 7 am, torch on.",
                "বুঝতে পারলাম না। বলুন: ইউটিউব খোলো, রহিমকে ফোন করো, সকাল ৭টায় অ্যালার্ম দাও, টর্চ জ্বালাও।")
        }
        thread { val a = askClaude(raw); main.post { reply(a) } }
    }

    // ---------- helpers ----------

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (_: Exception) { }
    }

    private fun normalize(s: String): String {
        val digits = "০১২৩৪৫৬৭৮৯"
        val sb = StringBuilder()
        for (c in s.lowercase()) { val i = digits.indexOf(c); sb.append(if (i >= 0) ('0' + i) else c) }
        return sb.toString().trim()
    }

    private fun has(t: String, vararg words: String) = words.any { t.contains(it) }

    private fun strip(t: String, vararg words: String): String {
        val drop = words.toSet()
        return t.split(" ", "।", ",").filter { it.isNotBlank() && it !in drop }.joinToString(" ").trim()
    }

    private var torchOn = false
    private fun setTorch(on: Boolean): Boolean {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return false
        cm.setTorchMode(id, on); torchOn = on
        return true
    }

    private fun lookupContact(name: String): String? {
        if (name.isBlank()) return null
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"), null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private val aliases = mapOf(
        "ইউটিউব" to "youtube", "হোয়াটসঅ্যাপ" to "whatsapp", "ফেসবুক" to "facebook", "ক্রোম" to "chrome",
        "ক্যামেরা" to "camera", "সেটিংস" to "settings", "গ্যালারি" to "photos", "ম্যাপ" to "maps",
        "জিমেইল" to "gmail", "মেসেঞ্জার" to "messenger", "ক্যালকুলেটর" to "calculator",
        "ঘড়ি" to "clock", "মেসেজ" to "messages", "ফোন" to "phone", "ইনস্টাগ্রাম" to "instagram",
        "টেলিগ্রাম" to "telegram", "স্পটিফাই" to "spotify",
        "লিংকডইন" to "linkedin", "লিঙ্কডইন" to "linkedin", "লিংকডিন" to "linkedin", "লিঙ্কডিন" to "linkedin",
        "টিকটক" to "tiktok", "জুম" to "zoom", "টুইটার" to "twitter", "স্ন্যাপচ্যাট" to "snapchat"
    )

    private val knownPackages = mapOf(
        "linkedin" to "com.linkedin.android", "whatsapp" to "com.whatsapp", "facebook" to "com.facebook.katana",
        "messenger" to "com.facebook.orca", "instagram" to "com.instagram.android",
        "youtube" to "com.google.android.youtube", "telegram" to "org.telegram.messenger",
        "spotify" to "com.spotify.music", "tiktok" to "com.zhiliaoapp.musically", "twitter" to "com.twitter.android",
        "x" to "com.twitter.android", "snapchat" to "com.snapchat.android", "gmail" to "com.google.android.gm",
        "zoom" to "us.zoom.videomeetings", "teams" to "com.microsoft.teams", "chrome" to "com.android.chrome",
        "maps" to "com.google.android.apps.maps"
    )

    private fun openStore(pkg: String?, name: String) {
        val market = if (pkg != null) "market://details?id=$pkg" else "market://search?q=" + Uri.encode(name) + "&c=apps"
        val web = if (pkg != null) "https://play.google.com/store/apps/details?id=$pkg"
                  else "https://play.google.com/store/search?c=apps&q=" + Uri.encode(name)
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(market)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse(web)))
        }
    }

    private fun openApp(spoken: String): Boolean {
        if (spoken.isBlank()) return false
        val name = (aliases[spoken] ?: spoken).lowercase()
        if (name == "settings") { start(Intent(Settings.ACTION_SETTINGS)); return true }
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        start(i); return true
    }

    private fun askClaude(question: String): String {
        return try {
            history.add("user" to question)
            val msgs = JSONArray()
            history.takeLast(10).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
            val body = JSONObject()
                .put("model", Config.MODEL).put("max_tokens", 400)
                .put("system", "You are Jarvix, a friendly voice assistant on a phone. Reply in the user's language " +
                    "(Bengali script for Bengali). Keep answers to 1-3 spoken sentences, no markdown, no lists.")
                .put("messages", msgs)
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", Config.API_KEY)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val text = JSONObject(c.inputStream.bufferedReader().readText())
                .getJSONArray("content").getJSONObject(0).getString("text").trim()
            history.add("assistant" to text); text
        } catch (e: Exception) {
            history.removeLastOrNull(); "Sorry, I could not reach the AI service. / সংযোগে সমস্যা হয়েছে।"
        }
    }
}
