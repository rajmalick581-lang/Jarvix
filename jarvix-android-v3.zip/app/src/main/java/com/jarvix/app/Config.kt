package com.jarvix.app

object Config {
    // Optional. Leave empty to use only built-in phone commands.
    // Add your Anthropic API key to let Jarvix answer general questions.
    // For personal use only: never publish an app with a key inside it.
    const val API_KEY = ""
    const val MODEL = "claude-sonnet-4-6"
}
