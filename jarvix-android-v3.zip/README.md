# Jarvix v3 (Android)

New in v3: conversation mode.
Say "Hey Jarvis" / "হে জার্ভিস". Jarvix wakes up, answers, and then keeps listening to everything you say
as commands for 40 seconds after each reply, with no need to repeat the wake word.
Say "goodbye" / "ধন্যবাদ" / "থামো" to put it back to sleep. It also sleeps by itself after 40 seconds of silence.

Setup: open in Android Studio, Run, tap the Hey Jarvix button, allow microphone and notifications,
turn on "Display over other apps", set Battery to Unrestricted.
A "Jarvix is listening" notification is always visible while the microphone is on. Tap Stop there to turn it off.
